<?php

namespace yii2bundle\db\console;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{
	
	public $actions;
	
}
