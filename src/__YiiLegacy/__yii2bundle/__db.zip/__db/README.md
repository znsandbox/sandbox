[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-db/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-db)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-db/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-db)

## Описание

модуль для применения дополнительных сценариев, кастомизации развертки проекта

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
