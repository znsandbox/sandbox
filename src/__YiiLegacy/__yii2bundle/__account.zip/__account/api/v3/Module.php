<?php

namespace yii2bundle\account\api\v3;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
