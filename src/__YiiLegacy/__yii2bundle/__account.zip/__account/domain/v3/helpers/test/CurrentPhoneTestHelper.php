<?php

namespace yii2bundle\account\domain\v3\helpers\test;

use yii2tool\test\helpers\BaseCacheTestHelper;

class CurrentPhoneTestHelper extends BaseCacheTestHelper
{

}
