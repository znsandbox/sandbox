<?php

namespace yii2bundle\account\domain\v3\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class ActivitySchema
 * 
 * @package yii2bundle\account\domain\v3\repositories\schema
 * 
 */
class ActivitySchema extends BaseSchema {

}
