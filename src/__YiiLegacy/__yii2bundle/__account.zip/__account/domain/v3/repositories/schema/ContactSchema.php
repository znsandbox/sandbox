<?php

namespace yii2bundle\account\domain\v3\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class ContactSchema
 * 
 * @package yii2bundle\account\domain\v3\repositories\schema
 * 
 */
class ContactSchema extends BaseSchema {

}
