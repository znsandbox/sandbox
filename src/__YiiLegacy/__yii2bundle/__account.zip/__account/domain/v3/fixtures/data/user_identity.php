<?php

return [
	[
		'id' => 1,
		'login' => 'admin',
		'status' => 1,
		'created_at' => '2018-03-28 21:00:13',
	],
	[
		'id' => 2,
		'login' => 'tester1',
		'status' => 1,
		'created_at' => '2018-03-28 21:00:13',
	],
	[
		'id' => 3,
		'login' => 'tester2',
		'status' => 1,
		'created_at' => '2018-03-28 21:00:13',
	],
	[
		'id' => 4,
		'login' => 'developer1',
		'status' => 1,
		'created_at' => '2018-03-28 21:00:13',
	],
	[
		'id' => 5,
		'login' => 'developer2',
		'status' => 1,
		'created_at' => '2018-03-28 21:00:13',
	],
];