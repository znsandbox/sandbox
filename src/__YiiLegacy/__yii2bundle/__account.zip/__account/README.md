[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-account/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-account)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-account/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-account)

## Описание

модуль пользователя.
Доменный слой и API модуль для обеспечения регистрации, авторизации и восстановления пароля пользователя.

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
