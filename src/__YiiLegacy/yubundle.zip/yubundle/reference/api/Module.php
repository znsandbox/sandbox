<?php

namespace yubundle\reference\api;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

}
