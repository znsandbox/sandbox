<?php

namespace yubundle\reference\admin;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

}
