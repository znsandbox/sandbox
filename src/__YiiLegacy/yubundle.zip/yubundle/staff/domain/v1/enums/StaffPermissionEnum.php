<?php

namespace yubundle\staff\domain\v1\enums;

use yii2rails\extension\enum\base\BaseEnum;

class StaffPermissionEnum extends BaseEnum
{

    const MANAGE = 'oStaffManage';

}
