<?php

return [
    1 => [
		'id' => 1,
		'code' => 1111,
		'name' => 'Rocket Firm',
		'status' => 1,
		'created_at' => '2019-03-26 21:34:00',
		'updated_at' => null,
	],
	2 => [
		'id' => 2,
		'code' => 2222,
		'name' => 'Legalbet',
		'status' => 1,
		'created_at' => '2019-03-26 21:34:00',
		'updated_at' => null,
	],
	3 => [
		'id' => 3,
		'code' => 333,
		'name' => 'Wooppay',
		'status' => 1,
		'created_at' => '2019-04-10 10:34:25',
		'updated_at' => '2019-04-10 10:34:25',
	],
	4 => [
		'id' => 4,
		'code' => 444,
		'name' => 'Test company',
		'status' => 1,
		'created_at' => '2019-04-10 10:34:25',
		'updated_at' => '2019-04-10 10:34:25',
	],
];