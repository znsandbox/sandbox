<?php

return [
    'company_posts_not_found' => 'У вашей компании нет должностей',
];
