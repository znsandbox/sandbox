<?php

return [
    'menu_title' => 'Компания',
    'title' => 'Компании',
    'division_manage' => 'Подразделения',
    'post_manage' => 'Должности',
    'new_company' => 'Создать компанию',
    'view_company' => 'Просмотреть компанию',
    'edit_company' => 'Редактировать компанию',
    'code' => 'Код компании',
    'name' => 'Название',
    'status' => 'Статус',
];