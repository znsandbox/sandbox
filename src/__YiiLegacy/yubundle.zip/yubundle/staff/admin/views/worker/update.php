<?php

/* @var $this yii\web\View */

?>

<?= $this->context->renderPartial('_form', compact('model')); ?>

