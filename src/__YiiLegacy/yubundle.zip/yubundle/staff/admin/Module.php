<?php

namespace yubundle\staff\admin;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{

}
