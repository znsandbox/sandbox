<?php

namespace yubundle\staff\api\v1;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
