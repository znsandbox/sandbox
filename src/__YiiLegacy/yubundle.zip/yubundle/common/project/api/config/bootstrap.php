<?php

Yii::$container->set('yii\data\Pagination', [
	'pageSizeLimit' => [10, 50],
]);
