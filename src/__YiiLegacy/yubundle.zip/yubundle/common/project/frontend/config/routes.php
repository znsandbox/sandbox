<?php

return [
	'' => 'welcome',
	
	'@import' => [
        'vendor/php7lab/yii2-legacy/src/yubundle/storage/web',
	],
	
];
