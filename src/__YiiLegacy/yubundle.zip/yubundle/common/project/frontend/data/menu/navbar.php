<?php

return [
	'mainMenu' => [
		'PhpLab\Sandbox\RestClient\Yii\Web\helpers\Menu',
	],
	'rightMenu' => [
		'yubundle\account\web\helpers\Menu',
	],
];