<?php

return [
	//'vendor' => 'yii2tool\vendor\console\Module',
    //'rest' => 'yii2bundle\rest\console\Module',
	//'db' => 'yii2bundle\db\console\Module',
    //'account' => 'yubundle\account\console\Module',
];
