<?php

return [
	'' => 'dashboard',
];
