<?php

include(__DIR__ . '/../../vendor/php7lab/yii2-legacy/src/yubundle/common/project/backend/config/bootstrap.php');
