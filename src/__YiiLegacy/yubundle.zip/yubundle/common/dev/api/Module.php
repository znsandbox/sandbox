<?php

namespace yubundle\common\dev\api;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
