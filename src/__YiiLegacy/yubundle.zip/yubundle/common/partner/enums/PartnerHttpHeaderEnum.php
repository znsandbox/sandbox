<?php

namespace yubundle\common\partner\enums;

use yii2rails\extension\enum\base\BaseEnum;

class PartnerHttpHeaderEnum extends BaseEnum {

	const AUTHORIZATION = 'Authorization-Partner';

}
