<?php

namespace yubundle\common\partner\interfaces\repositories;

/**
 * Interface AuthInterface
 * 
 * @package yubundle\common\partner\interfaces\repositories
 * 
 * @property-read \yubundle\common\partner\Domain $domain
 */
interface AuthInterface {

}
