<?php

namespace yubundle\common\partner\interfaces\repositories;

/**
 * Interface RepositoriesInterface
 * 
 * @package yubundle\common\partner\interfaces\repositories
 * 
 * @property-read \yubundle\common\partner\interfaces\repositories\AuthInterface $auth
 */
interface RepositoriesInterface {

}
