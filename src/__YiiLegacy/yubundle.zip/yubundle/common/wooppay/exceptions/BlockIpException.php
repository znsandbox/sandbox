<?php

namespace yubundle\common\wooppay\exceptions;

use yii\base\Exception;

class BlockIpException extends Exception {

}
