<?php

namespace yubundle\common\wooppay\exceptions;

use yii\base\Exception;

class CancelOperationException extends Exception {

}
