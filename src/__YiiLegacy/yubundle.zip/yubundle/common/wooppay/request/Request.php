<?php

namespace yubundle\common\wooppay\request;

use yii\base\Model;

class Request extends Model
{

    private $methodName;

    public function send() {

    }

}
