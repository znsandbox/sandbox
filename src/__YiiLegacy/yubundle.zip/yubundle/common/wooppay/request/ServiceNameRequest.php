<?php

namespace yubundle\common\wooppay\request;

class ServiceNameRequest extends Request
{

    public $service_name;

}
