<?php

namespace yubundle\common\wooppay\response;

use yii\base\Model;

class Response extends Model
{

    public $response;
    public $error_code;

}
