<?php

namespace yubundle\common\wooppay\models;

class ConfigModel
{

    public $url;
    public $username;
    public $password;
    public $storeClass;
    public $autoAuth = false;

}
