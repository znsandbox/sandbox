<?php

return [
    [
        'user_id' => 1,
        'item_name' => 'rAdministrator',
    ],
    [
        'user_id' => 4,
        'item_name' => 'rNewsEditor',
    ],
    [
        'user_id' => 5,
        'item_name' => 'rNewsEditor',
    ],
];