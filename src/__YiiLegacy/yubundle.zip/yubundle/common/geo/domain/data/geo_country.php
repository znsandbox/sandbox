<?php

return [
	398 => [
		'id' => 398,
		'name' => 'Kazakhstan',
		'alpha2' => 'KZ',
		'alpha3' => 'KAZ',
	],
	643 => [
		'id' => 643,
		'name' => 'Russian Federation',
		'alpha2' => 'RU',
		'alpha3' => 'RUS',
	],
	250 => [
		'id' => 250,
		'name' => 'France',
		'alpha2' => 'FR',
		'alpha3' => 'FRA',
	],
	840 => [
		'id' => 840,
		'name' => 'United States of America',
		'alpha2' => 'US',
		'alpha3' => 'USA',
	],
];