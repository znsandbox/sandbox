<?php

namespace yubundle\account\console;

use yii2rails\domain\helpers\DomainHelper;

class Module extends \yii\base\Module {

}
