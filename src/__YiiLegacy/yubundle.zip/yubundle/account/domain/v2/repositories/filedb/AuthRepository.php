<?php

namespace yubundle\account\domain\v2\repositories\filedb;

use yubundle\account\domain\v2\interfaces\repositories\AuthInterface;
use yubundle\account\domain\v2\repositories\base\BaseAuthRepository;

class AuthRepository extends BaseAuthRepository implements AuthInterface {
}