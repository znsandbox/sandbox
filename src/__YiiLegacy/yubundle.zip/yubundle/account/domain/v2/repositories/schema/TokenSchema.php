<?php

namespace yubundle\account\domain\v2\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class TokenSchema
 * 
 * @package yubundle\account\domain\v2\repositories\schema
 * 
 */
class TokenSchema extends BaseSchema {

}
