<?php

namespace yubundle\account\domain\v2\chain;

use yubundle\account\domain\v2\chain\BaseHandler;

class ConcreteHandler extends BaseHandler {

    public function get($request) {

    }

}
