<?php

return [
	[
		'user_id' => 381949,
		'item_name' => 'rAdministrator',
	],
	[
		'user_id' => 381069,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 381070,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 375664,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 381072,
		'item_name' => 'rFinanceSpecialist',
	],
	[
		'user_id' => 381073,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 381074,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 381074,
		'item_name' => 'rResmiUnknownUser',
	],
	[
		'user_id' => 381075,
		'item_name' => 'rUnknownUser',
	],
	[
		'user_id' => 381076,
		'item_name' => 'rAdministrator',
	],
	
];
