<?php

$passwordHash = '$2y$13$Xt.Zo0sIeIPi6CvraoUB1eihsZO3pFXx4rcYGWL9jGRr0YybqCqdK';

return [
	[
		'id' => 381949,
		//'email' => null,
		'auth_key' => '4f6bbd8ea39e34f2f2d432a961be2a6a',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381069,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg2',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381070,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg3',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 375664,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg4',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381072,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg5',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381073,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg6',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381074,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg7',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381075,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg8',
		'password_hash' => $passwordHash,
	],
	[
		'id' => 381076,
		//'email' => null,
		'auth_key' => 'CUc6h7DyU07Lbru0QWu4-jb0Tiz15qWQZZ8IIix0sq5XO6-nWbtmImx93aTq4Cg9',
		'password_hash' => $passwordHash,
	],
];
