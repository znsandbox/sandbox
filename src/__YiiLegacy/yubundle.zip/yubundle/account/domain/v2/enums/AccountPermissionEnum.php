<?php

namespace yubundle\account\domain\v2\enums;

use yii2rails\extension\enum\base\BaseEnum;

class AccountPermissionEnum extends BaseEnum
{



}