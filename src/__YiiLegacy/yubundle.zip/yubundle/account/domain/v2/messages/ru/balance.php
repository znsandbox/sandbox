<?php

return [
	'title' => 'Баланс',
];