<?php

return [
	'incorrect_login_or_code'=>'Неверный логин или код подтверждения',
	'already_sended_code {phone}' => 'Код подтверждения уже был выслан на номер: {phone}',
	'confirmation_code {code}' => 'Код подтверждения: {code}',
	'incorrect_code' => 'Неверный код подтверждения',
    'confirm_code_attempt_error' => 'Исчерпаны попытки ввода кода активации. Запросите СМС-код заново.',
	'not_be_activated' => 'Запрос не был активирован',
    'not_found' => 'Не найден запрос кода активации, выполните первый шаг',
];