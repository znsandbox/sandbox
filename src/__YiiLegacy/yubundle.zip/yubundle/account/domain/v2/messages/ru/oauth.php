<?php

return [
	'title' => 'OAuth',
	'login_text' => 'Авторизация через соцсеть',
];
