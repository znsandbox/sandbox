<?php

return [
	'title' => 'Аккаунт',
	'not_valid' => 'Неверный формат аккаунта',
    'status_disabled_message' => 'Аккаунт не активен',
];