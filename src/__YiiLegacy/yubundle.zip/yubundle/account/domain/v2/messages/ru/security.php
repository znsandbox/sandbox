<?php

return [
	'title' => 'Безопасность',
	
	'email' => 'Почта',
	'password' => 'Пароль',
	
	'email_changed_success'=>'Почта успешно изменена',
	'password_changed_success'=>'Пароль успешно изменен',
	
	'new_password_repeat' => 'Подтвердите новый пароль',
	'new_password'=>'Новый пароль',
];