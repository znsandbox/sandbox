
var host = {
    "api.yumail.project": {
        "api": "http://api.yumail.project/v1",
        "socket": "ws://127.0.0.1",
    },
    "test-api.yumail.kz": {
        "api": "https://test-api.yumail.kz/v1",
        "socket": "wss://test-api.yumail.kz",
    },
    "api.yumail.kz": {
        "api": "https://api.yumail.kz/v1",
        "socket": "wss://api.yumail.kz",
    },
    "api.t-cloud.kz": {
        "api": "https://api.t-cloud.kz/v1",
        "socket": "wss://api.t-cloud.kz",
    },
};
