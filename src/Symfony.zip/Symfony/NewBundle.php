<?php

namespace ZnSandbox\Sandbox\Symfony;

use ZnCore\Base\Helpers\DeprecateHelper;
use ZnCore\Base\Libs\App\Base\BaseBundle;

DeprecateHelper::hardThrow();

class NewBundle extends BaseBundle
{

    public function deps(): array
    {
        return [

        ];
    }
    
    public function container(): array
    {
        return [
            __DIR__ . '/Domain/config/container-symfony.php',
            __DIR__ . '/Domain/config/container-zn-web.php',
            __DIR__ . '/Domain/config/container-zn-bundles.php',
        ];
    }
}
