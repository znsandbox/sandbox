<?php

namespace yii2bundle\rbac\console;

use yii\base\Module as YiiModule;

/**
 * rbac module definition class
 */
class Module extends YiiModule
{
	
}
