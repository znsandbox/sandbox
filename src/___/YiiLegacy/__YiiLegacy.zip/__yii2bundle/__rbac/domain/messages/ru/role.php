<?php

return [
	'already_exists' => 'Роль уже существует',
];
