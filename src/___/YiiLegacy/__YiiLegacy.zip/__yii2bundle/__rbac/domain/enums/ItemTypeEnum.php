<?php

namespace yii2bundle\rbac\domain\enums;

use yii2rails\extension\enum\base\BaseEnum;

class ItemTypeEnum extends BaseEnum
{

    const ROLE = 1;
	const PERMISSION = 2;

}