<?php

namespace yii2bundle\rbac\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class PermissionSchema
 * 
 * @package yii2bundle\rbac\domain\repositories\schema
 * 
 */
class PermissionSchema extends BaseSchema {

}
