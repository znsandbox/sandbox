<?php

namespace yii2bundle\rbac\domain\repositories\file;

use yii2rails\domain\repositories\BaseRepository;

class ItemRepository extends BaseRepository {

}
