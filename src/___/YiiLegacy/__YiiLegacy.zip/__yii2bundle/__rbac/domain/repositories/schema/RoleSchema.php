<?php

namespace yii2bundle\rbac\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class RoleSchema
 * 
 * @package yii2bundle\rbac\domain\repositories\schema
 * 
 */
class RoleSchema extends BaseSchema {

}
