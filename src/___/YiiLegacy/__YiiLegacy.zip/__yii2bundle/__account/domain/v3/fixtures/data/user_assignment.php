<?php

return [
	[
		'user_id' => 1,
		'item_name' => 'rAdministrator',
	],
	[
		'user_id' => 2,
		'item_name' => 'rTester',
	],
	[
		'user_id' => 3,
		'item_name' => 'rTester',
	],
	[
		'user_id' => 4,
		'item_name' => 'rDeveloper',
	],
	[
		'user_id' => 5,
		'item_name' => 'rDeveloper',
	],
];