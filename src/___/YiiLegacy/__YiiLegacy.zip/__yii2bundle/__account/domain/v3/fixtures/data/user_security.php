<?php

return [
	1 => [
		'id' => 1,
		'identity_id' => 1,
		'password_hash' => '$2y$10$VeTx5VTpb4AGoLRO6FfVxuNM5Xqbf7SgbC1LMvuMAi28RB9v3lPj.',
	],
	2 => [
		'id' => 2,
		'identity_id' => 2,
		'password_hash' => '$2y$10$VeTx5VTpb4AGoLRO6FfVxuNM5Xqbf7SgbC1LMvuMAi28RB9v3lPj.',
	],
	3 => [
		'id' => 3,
		'identity_id' => 3,
		'password_hash' => '$2y$10$VeTx5VTpb4AGoLRO6FfVxuNM5Xqbf7SgbC1LMvuMAi28RB9v3lPj.',
	],
	4 => [
		'id' => 4,
		'identity_id' => 4,
		'password_hash' => '$2y$10$VeTx5VTpb4AGoLRO6FfVxuNM5Xqbf7SgbC1LMvuMAi28RB9v3lPj.',
	],
	5 => [
		'id' => 5,
		'identity_id' => 5,
		'password_hash' => '$2y$10$VeTx5VTpb4AGoLRO6FfVxuNM5Xqbf7SgbC1LMvuMAi28RB9v3lPj.',
	],
];