<?php

namespace yii2bundle\account\domain\v3\enums;

use yii2rails\extension\enum\base\BaseEnum;

class AccountEventEnum extends BaseEnum
{

    const AUTHENTICATION = 'authentication';

}