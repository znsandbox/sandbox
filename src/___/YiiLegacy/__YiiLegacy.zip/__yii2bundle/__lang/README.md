[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-lang/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-lang)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-lang/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-lang)

## Описание

модуль мультиязычности

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
