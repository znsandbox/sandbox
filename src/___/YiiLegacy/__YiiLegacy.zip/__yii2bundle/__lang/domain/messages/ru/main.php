<?php

return [
	'title' => 'Язык',
	'language_id' => 'Язык ID',
	'name' => 'Имя',
	'language' => 'Язык',
	'code'=>'Код',
	'locale'=>'Локаль',
	'main_as_default'=>'Основной язык',
	
	'title_languages' => 'Языки',
];
