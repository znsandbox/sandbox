<?php
return [
	'title' => 'Управление языками',
];