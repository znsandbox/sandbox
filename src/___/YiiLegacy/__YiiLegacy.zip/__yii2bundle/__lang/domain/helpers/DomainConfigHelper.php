<?php

namespace yii2bundle\lang\domain\helpers;

class DomainConfigHelper {

}
