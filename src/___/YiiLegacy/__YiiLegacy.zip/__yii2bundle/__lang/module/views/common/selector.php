<?php

use yii2bundle\lang\widgets\LangSelector;

?>

<span class="dropup">
	<?= LangSelector::widget() ?>
</span>
