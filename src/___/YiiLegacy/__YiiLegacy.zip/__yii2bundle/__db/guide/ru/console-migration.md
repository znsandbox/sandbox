Миграции
===

Генерировать миграцию:

```
cd vendor/yii2bundle/yii2-db/bin
php bin migration/generate
```

структура и связи будут взяты из текущей БД.

Инициализировать фильтры для БД:

```
cd vendor/yii2bundle/yii2-db/bin
php bin init
```
