<?php

return [
	'bad_format' => 'Некорректный номер телефона',
];