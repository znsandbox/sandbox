<?php

namespace yii2bundle\geo\domain\fixtures;

use yii\test\ActiveFixture;

class GeoCurrencyFixture extends ActiveFixture
{
	public $tableName = '{{%geo_currency}}';
}