<?php 

return [
	1 => [
		'id' => 1,
		'country_id' => 1894,
		'code' => 'KZT',
		'name' => 'Казахский тенге',
		'description' => null,
	],
];