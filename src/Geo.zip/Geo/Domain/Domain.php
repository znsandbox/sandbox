<?php

namespace ZnSandbox\Sandbox\Geo\Domain;

use ZnCore\Domain\Interfaces\DomainInterface;

class Domain implements DomainInterface
{

    public function getName()
    {
        return 'geo';
    }


}

