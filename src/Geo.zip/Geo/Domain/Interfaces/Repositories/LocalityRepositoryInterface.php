<?php

namespace ZnSandbox\Sandbox\Geo\Domain\Interfaces\Repositories;

use ZnCore\Domain\Interfaces\Repository\CrudRepositoryInterface;

interface LocalityRepositoryInterface extends CrudRepositoryInterface
{


}

