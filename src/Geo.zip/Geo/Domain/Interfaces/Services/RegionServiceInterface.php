<?php

namespace ZnSandbox\Sandbox\Geo\Domain\Interfaces\Services;

use ZnCore\Domain\Interfaces\Service\CrudServiceInterface;

interface RegionServiceInterface extends CrudServiceInterface
{


}

