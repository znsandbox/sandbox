<?php

namespace ZnLib\Rpc\Domain\Interfaces\Services;

use ZnCore\Domain\Interfaces\Service\CrudServiceInterface;

interface VersionHandlerServiceInterface extends \ZnLib\Rpc\Domain\Interfaces\Services\VersionHandlerServiceInterface //CrudServiceInterface
{


}

