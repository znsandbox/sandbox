<?php

namespace ZnLib\Rpc\Domain\Interfaces\Services;

interface SettingsServiceInterface extends \ZnLib\Rpc\Domain\Interfaces\Services\SettingsServiceInterface
{

//    public function update(SettingsEntity $settingsEntity);
//    public function view(): SettingsEntity;
}

