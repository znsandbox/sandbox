<?php

namespace ZnLib\Rpc\Domain\Interfaces\Repositories;

use ZnCore\Domain\Interfaces\Repository\CrudRepositoryInterface;

interface VersionHandlerRepositoryInterface extends \ZnLib\Rpc\Domain\Interfaces\Repositories\VersionHandlerRepositoryInterface // CrudRepositoryInterface
{


}

