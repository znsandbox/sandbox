<?php

namespace ZnLib\Rpc\Domain\Enums;

class RpcCryptoProviderStrategyEnum extends \ZnLib\Rpc\Domain\Enums\RpcCryptoProviderStrategyEnum
{

    /*const DEFAULT = 'default';
    const JSON_DSIG = 'jsonDSig';*/
}
