<?php

namespace ZnLib\Rpc\Domain\Enums;

class RpcEventEnum extends \ZnLib\Rpc\Domain\Enums\RpcEventEnum
{

    /** До выполнения экшена */
    /*const BEFORE_RUN_ACTION = 'before_run_action';

    const AFTER_RUN_ACTION = 'after_run_action';*/

}
