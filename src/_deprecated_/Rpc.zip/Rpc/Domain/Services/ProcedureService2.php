<?php

namespace ZnLib\Rpc\Domain\Services;

class ProcedureService2 extends \ZnLib\Rpc\Domain\Services\ProcedureService2 // ProcedureService
{

    /*public function subscribes(): array
    {
        return [
            
        ];
    }*/
}
