<?php

/**
 * @var $docs Collection | DocEntity[]
 */

use Illuminate\Support\Collection;
use ZnLib\Rpc\Domain\Entities\DocEntity;

?>

<div class="jumbotron">
    <h1 class="display-4">Hello, world!</h1>
    <p class="lead">
        This is a simple hero unit, a simple jumbotron-style component
        for calling extra attention to featured content or information.
    </p>
</div>
