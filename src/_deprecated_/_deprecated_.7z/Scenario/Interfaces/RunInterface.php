<?php

namespace ZnCore\Base\Scenario\Interfaces;

interface RunInterface
{

    public function run();

}
