<?php

namespace ZnCore\Base\Scenario\Exceptions;

use Exception;

class DetectedException extends Exception
{

}
