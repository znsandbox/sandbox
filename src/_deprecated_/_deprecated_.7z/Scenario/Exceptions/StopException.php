<?php

namespace ZnCore\Base\Scenario\Exceptions;

use Exception;

class StopException extends Exception
{

}
