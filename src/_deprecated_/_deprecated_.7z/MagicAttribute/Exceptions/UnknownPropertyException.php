<?php

namespace ZnCore\Base\MagicAttribute\Exceptions;

use Exception;

/**
 *
 */
class UnknownPropertyException extends Exception
{

}
