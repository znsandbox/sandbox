<?php

namespace ZnCore\Base\MagicAttribute\Exceptions;

use BadMethodCallException;

/**
 * Ошибка обращения к атрибуту
 */
class InvalidCallException extends BadMethodCallException
{

}
