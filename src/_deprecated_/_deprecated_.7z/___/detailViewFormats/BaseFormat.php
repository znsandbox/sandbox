<?php

namespace ZnLib\Web\Yii2\Widgets\detailViewFormats;

abstract class BaseFormat {
	
	abstract public function run($value);

}
