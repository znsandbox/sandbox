<?php

namespace ZnLib\Web\Yii2\Widgets;

class DropdownMenu extends Menu
{
	public $options = ['class' => 'dropdown-menu dropdown-menu-right'];
	public $activateParents = true;
}