<?php
namespace ZnLib\Web\Yii2\Widgets;

class Pills extends \yii\bootstrap\Tabs
{
	public $navType = 'nav-pills';
}
