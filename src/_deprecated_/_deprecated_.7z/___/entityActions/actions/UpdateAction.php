<?php

namespace ZnLib\Web\Yii2\Widgets\entityActions\actions;

class UpdateAction extends BaseAction {
	
	public $icon = 'pencil';
	public $textType = 'primary';
	public $action = 'update';
	public $title = ['action', 'update'];

}