[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-rest/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-rest)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-rest/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-rest)

## Описание

набор базовых классов для создания API

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
