<?php

namespace yii2bundle\rest\console;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{
	
}
