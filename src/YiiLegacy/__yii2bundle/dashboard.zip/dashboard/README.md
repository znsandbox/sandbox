[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-dashboard/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-dashboard)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-dashboard/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-dashboard)

## Описание

Страница приветствия

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
