<?php

namespace yii2bundle\dashboard\domain;

class Domain extends \yii2rails\domain\Domain {
	
	public function config() {
		return [];
	}
	
}