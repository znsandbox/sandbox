<?php

return [
	[
		'id' => 3,
		'field_id' => 2,
		'name' => 'required',
		'params' => null,
		'sort' => 10,
		'status' => 1,
	],
	[
		'id' => 2,
		'field_id' => 1,
		'name' => 'required',
		'params' => null,
		'sort' => 10,
		'status' => 1,
	],
	[
		'id' => 5,
		'field_id' => 3,
		'name' => 'required',
		'params' => null,
		'sort' => 10,
		'status' => 1,
	],
	[
		'id' => 4,
		'field_id' => 2,
		'name' => 'yii2rails\\extension\\validator\\IinValidator',
		'params' => null,
		'sort' => 20,
		'status' => 1,
	],
	[
		'id' => 1,
		'field_id' => 1,
		'name' => 'birthday',
		'params' => null,
		'sort' => 20,
		'status' => 1,
	],
];