<?php

return [
	[
		'id' => 1,
		'name' => 'person',
		'handler' => null,
		'status' => 1,
	],
];