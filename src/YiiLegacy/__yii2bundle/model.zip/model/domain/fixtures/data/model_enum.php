<?php

return [
	[
		'id' => 1,
		'field_id' => 3,
		'name' => 'male',
		'title' => 'Мжчина',
		'status' => 1,
		'sort' => 10,
	],
	[
		'id' => 2,
		'field_id' => 3,
		'name' => 'female',
		'title' => 'Женщина',
		'status' => 1,
		'sort' => 20,
	],
];