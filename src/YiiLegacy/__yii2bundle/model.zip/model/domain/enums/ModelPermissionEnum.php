<?php

namespace yii2bundle\model\domain\enums;

use yii2rails\extension\enum\base\BaseEnum;

class ModelPermissionEnum extends BaseEnum
{

    // Управление моделями
    const MANAGE = 'oModelManage';

}