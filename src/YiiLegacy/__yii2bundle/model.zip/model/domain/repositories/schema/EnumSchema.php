<?php

namespace yii2bundle\model\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class EnumSchema
 * 
 * @package yii2bundle\model\domain\repositories\schema
 * 
 */
class EnumSchema extends BaseSchema {

}
