<?php

namespace yii2bundle\model\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class RuleSchema
 * 
 * @package yii2bundle\model\domain\repositories\schema
 * 
 */
class RuleSchema extends BaseSchema {

}
