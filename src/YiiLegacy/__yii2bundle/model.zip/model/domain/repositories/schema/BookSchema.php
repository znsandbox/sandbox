<?php

namespace yii2bundle\model\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class BookSchema
 * 
 * @package yii2bundle\model\domain\repositories\schema
 * 
 */
class BookSchema extends BaseSchema {

}
