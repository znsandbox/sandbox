<?php

namespace yii2bundle\model\api\v1;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
