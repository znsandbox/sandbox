<?php

return [
	'already_exists' => 'Полномочие уже существует',
];
