<?php

namespace tests\functional\enums;

use yii2rails\extension\enum\base\BaseEnum;

class LoginEnum extends BaseEnum {
	
	const ID_ADMIN = 1;
	const ID_USER = 3;
	
}
