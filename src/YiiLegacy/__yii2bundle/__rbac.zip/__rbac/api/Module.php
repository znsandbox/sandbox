<?php

namespace yii2bundle\rbac\api;

use yii\base\Module as YiiModule;

class Module extends YiiModule
{
	
}
