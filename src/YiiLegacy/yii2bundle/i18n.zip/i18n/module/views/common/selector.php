<?php

use yii2bundle\i18n\widgets\LangSelector;

?>

<span class="dropup">
	<?= LangSelector::widget() ?>
</span>
