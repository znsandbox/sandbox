<?php

namespace yii2bundle\i18n\module;

use yii\base\Module as YiiModule;

/**
 * lang module definition class
 */
class Module extends YiiModule
{
	public static $langDir = '@yii2bundle/i18n/domain/messages';
}
