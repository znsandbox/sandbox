<?php

namespace yii2bundle\i18n\domain\helpers;

class DomainConfigHelper {

}
