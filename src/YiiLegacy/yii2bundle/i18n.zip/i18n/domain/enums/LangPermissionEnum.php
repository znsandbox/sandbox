<?php

namespace yii2bundle\i18n\domain\enums;

use yii2rails\extension\enum\base\BaseEnum;

class LangPermissionEnum extends BaseEnum
{

    // Управление языками
    const MANAGE = 'oLangManage';

}