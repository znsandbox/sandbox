<?php

return [
	[
		'id' => 1,
		'domain_id' => 1,
		'name' => 'article',
		'title' => 'Статья',
	],
	[
		'id' => 2,
		'domain_id' => 1,
		'name' => 'category',
		'title' => 'Категория',
	],
];