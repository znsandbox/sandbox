<?php

namespace yii2bundle\i18n\domain\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class FieldSchema
 * 
 * @package yii2bundle\i18n\domain\repositories\schema
 * 
 */
class FieldSchema extends BaseSchema {

}
