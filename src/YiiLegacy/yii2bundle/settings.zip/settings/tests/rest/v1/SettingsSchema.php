<?php

namespace yii2bundle\settings\tests\rest\v1;

use yii2tool\test\enums\TypeEnum;

class SettingsSchema
{

    public static $settings = [
        'language' => TypeEnum::STRING,
    ];

}
