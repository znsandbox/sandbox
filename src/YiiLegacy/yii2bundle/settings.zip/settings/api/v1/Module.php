<?php

namespace yii2bundle\settings\api\v1;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
