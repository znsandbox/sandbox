<?php

namespace yii2bundle\settings\domain\v1\repositories\schema;

use yii2rails\domain\repositories\relations\BaseSchema;

/**
 * Class PersonalSchema
 *
 * @package yii2bundle\settings\domain\v1\repositories\schema
 *
 */
class PersonalSchema extends BaseSchema
{

}
