<?php

return [
    'phone_or_email_required' => 'Заполните телефон или почту',
    'contact_already_exist' => 'Контакт с такими данными уже существует',
];