[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-notify/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-notify)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-notify/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-notify)

## Описание

сервис для отправки SMS, Email и Push

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
