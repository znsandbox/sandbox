<?php

namespace yii2bundle\notify\admin;

use yii\base\Module as YiiModule;
use yii2bundle\notify\domain\enums\NotifyPermissionEnum;
use yii2rails\extension\web\helpers\Behavior;

/**
 * dashboard module definition class
 */
class Module extends YiiModule
{

    public function behaviors()
    {
        return [
            'access' => Behavior::access(NotifyPermissionEnum::MANAGE),
        ];
    }

}
