<?php

namespace yii2bundle\notify\domain\job;

use App;
use yii\base\BaseObject;
use yii\queue\JobInterface;
use yii2bundle\notify\domain\entities\EmailEntity;

class EmailJob extends BaseObject implements JobInterface {

    public $from;
	public $address;
	public $subject;
	public $content;
	public $attachments;
	
	public function execute($queue) {
		$email = new EmailEntity();
        $email->from = $this->from;
		$email->address = $this->address;
		$email->subject = $this->subject;
		$email->content = $this->content;
		$email->attachments = $this->attachments;
		App::$domain->notify->email->directSendEntity($email);
	}
}
