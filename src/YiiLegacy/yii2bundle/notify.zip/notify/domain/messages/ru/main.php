<?php
return [
	'title'=>'Уведомления',
	'sms'=>'SMS',
	'email'=>'Email',
	'message_success_send' => 'Сообщение успешно отправлено',
	
	'address' => 'Адрес',
	'subject' => 'Тема',
	'content' => 'Сообщение',

    'messages_deleted' => 'Сообщения очищены!',
];