<?php

namespace yii2bundle\notify\domain\entities;

use yii\behaviors\TimestampBehavior;
use yii2bundle\notify\domain\enums\SmsStatusEnum;
use yii2rails\domain\BaseEntity;
use yii2rails\domain\behaviors\entity\TimeValueFilter;

/**
 * Class SmsQueueEntity
 * 
 * @package yii2bundle\notify\domain\entities
 * 
 * @property $id
 * @property $phone
 * @property $content
 * @property $status
 * @property $updated_at
 * @property $created_at
 * @property $format
 */
class SmsQueueEntity extends BaseEntity {

	protected $id;
	protected $phone;
	protected $content;
	protected $status = SmsStatusEnum::NEW;
	protected $updated_at;
	protected $created_at;
	protected $format;

    public function behaviors()
    {
        return [
            [
                'class' => TimeValueFilter::class,
            ],
        ];
    }

    public function rules()
    {
        return [
            [['phone','content', 'status'], 'required'],
            ['status', 'in', 'range' => SmsStatusEnum::values()],
            [['format'], 'integer'],
        ];
    }
}
