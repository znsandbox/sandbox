<?php

namespace yii2bundle\notify\domain\exceptions;

class SmsTimeLimitException extends \Exception {

}
