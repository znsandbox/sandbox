Email
===

Отправка Email-сообщения

```php
App::$domain->notify->email->send('qwerty@ya.ru', 'тема письма', 'текст письма');
```