Sms
===

Отправка SMS-сообщения

```php
App::$domain->notify->sms->send('77771111111', 'текст сообщения');
```
