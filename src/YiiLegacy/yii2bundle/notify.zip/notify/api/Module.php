<?php

namespace yii2bundle\notify\api;

use yii\base\Module as YiiModule;

/**
 * user module definition class
 */
class Module extends YiiModule
{
 
 
	
}
