[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-geo/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-geo)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-geo/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-geo)

## Описание

модуль для работы с гео-данными: страна, область, город, валюта

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
