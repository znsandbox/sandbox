<?php

namespace yii2bundle\geo\domain\fixtures;

use yii\test\ActiveFixture;

class GeoCityFixture extends ActiveFixture
{
	public $tableName = '{{%geo_city}}';
}