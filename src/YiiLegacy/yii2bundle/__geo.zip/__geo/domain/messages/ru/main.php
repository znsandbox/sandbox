<?php
return [
	'title' => 'Geo',
	'select_country' => '- Выберите страну -',
	'select_region' => '- Выберите регион -',
	'select_city' => '- Выберите город -',
];