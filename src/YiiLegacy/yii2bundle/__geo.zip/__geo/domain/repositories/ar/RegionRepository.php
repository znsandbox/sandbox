<?php

namespace yii2bundle\geo\domain\repositories\ar;

use yii2rails\extension\activeRecord\repositories\base\BaseActiveArRepository;

class RegionRepository extends BaseActiveArRepository {
	
	protected $schemaClass = true;
	
}
