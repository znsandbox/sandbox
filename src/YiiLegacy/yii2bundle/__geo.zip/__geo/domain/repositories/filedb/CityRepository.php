<?php

namespace yii2bundle\geo\domain\repositories\filedb;

use yii2rails\extension\filedb\repositories\base\BaseActiveFiledbRepository;

class CityRepository extends BaseActiveFiledbRepository {
	
	protected $schemaClass = true;
	
}
