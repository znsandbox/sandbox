<?php

namespace yii2bundle\navigation\domain\repositories\memory;

use yii2rails\extension\arrayTools\repositories\base\BaseActiveArrayRepository;
use yii2bundle\navigation\domain\interfaces\repositories\BreadcrumbsInterface;

class BreadcrumbsRepository extends BaseActiveArrayRepository implements BreadcrumbsInterface {

}
