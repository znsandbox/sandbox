<?php

namespace yii2bundle\navigation\domain\interfaces\repositories;

use yii2rails\domain\interfaces\repositories\CrudInterface;

interface BreadcrumbsInterface extends CrudInterface {

}