[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-navigation/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-navigation)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-navigation/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-navigation)

## Описание

сервис для работы элементами навигации на странице

## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)