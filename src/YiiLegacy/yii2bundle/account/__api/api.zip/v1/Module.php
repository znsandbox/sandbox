<?php

namespace yii2bundle\account\api\v1;

use yii\base\Module as YiiModule;

/**
 * user module definition class
 */
class Module extends YiiModule
{
 
 
	
}
