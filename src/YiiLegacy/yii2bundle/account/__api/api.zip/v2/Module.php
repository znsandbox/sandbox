<?php

namespace yii2bundle\account\api\v2;

use yii\base\Module as YiiModule;

class Module extends YiiModule {

}
