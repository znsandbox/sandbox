<?php

return [
	'mainMenu' => [
		'PhpLab\Sandbox\RestClient\Yii\Web\helpers\Menu',
	],
	'rightMenu' => [
		'yii2bundle\account\module\helpers\Menu',
	],
];