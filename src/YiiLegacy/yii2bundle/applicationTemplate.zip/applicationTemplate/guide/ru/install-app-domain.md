Настройка доменов
==============

Назначить домены

* API - `api.example.project` - `api/web`
* админка - `admin.example.project` - `backend/web`
* сайт - `web.example.project` - `frontend/web`
