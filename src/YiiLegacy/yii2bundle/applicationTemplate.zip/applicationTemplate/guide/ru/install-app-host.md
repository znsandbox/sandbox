# Хосты

## Введение

Вместо `example.com` вставляем нужный домен.

## Тестовый

* `test-api.example.com` - API
* `test-admin.example.com` - Admin
* `test-web.example.com` - Frontend
* `test.example.com` - SPA

## Боевой

* `api.example.com` - API
* `admin.example.com` - Admin
* `web.example.com` - Frontend
* `example.com` - SPA

## Локальный

* `api.example.project` - API
* `admin.example.project` - Admin
* `web.example.project` - Frontend
* `example.project` - SPA

## Пути для доменов

* `api.example.com` - api/web
* `admin.example.com` - backend/web
* `example.com` - frontend/web
