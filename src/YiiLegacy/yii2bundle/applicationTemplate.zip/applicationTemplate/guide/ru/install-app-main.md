Установка
===

## Шаги установки

* [Развертывание проекта](install-app-create.md)
* [Установка зависимостей](install-app-dependency.md)
* [Подготовка БД](install-app-db.md)
* [Настройка доменов](install-app-domain.md)
* [Доступы на сайт](install-app-access-demo.md)
* [Запуск автотестов](install-app-autotest.md)
* [Деплой](install-app-deploy.md)
