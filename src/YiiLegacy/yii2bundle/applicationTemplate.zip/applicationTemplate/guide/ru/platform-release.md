CHANGELOG
===

## [Unreleased]

## 2018-02-03

### Changed

* move fixture functional to `yii2lab/yii2-db` package
* move migration functional to `yii2lab/yii2-db` package
* rename command `environments` to `init/environments`

### Deprecated

* use a query object instead of with array in `RelationHelper::load`

### Fixed

* fixture table list for export

### Added

* batch git push for packages

## 2018-02-01

### Changed

* test

### Fixed

* menu in rest client
* last insert id

### Added

* batch run tests from project and packages
* link to Github from guide article
* guide for test
