Автотесты
===

Проектные и пакетные тесты:

```
cd vendor/yii2tool/yii2-vendor/bin
php bin test/package
php bin test/project
```

АПИ тесты:

```
cd api
php "../vendor/codeception/base/codecept" run
```
