Установка
===

Устанавливаем зависимость:

```
composer require yii2lab/yii2-application-template
```
