<?php
namespace tests\unit;

use yii2tool\test\Test\Unit;

class DefaultTest extends Unit
{
	
	public function testMy()
	{
		$this->tester->assertEquals(1, 1);
	}
	
}
