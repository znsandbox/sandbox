<?php

use yii2tool\test\helpers\TestHelper;

return TestHelper::loadConfigFromPath(__DIR__);
