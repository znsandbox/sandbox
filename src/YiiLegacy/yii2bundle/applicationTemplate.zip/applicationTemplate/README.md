[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-application-template/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-application-template)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-application-template/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-application-template)

## Описание



## Ссылки

* [Руководство](guide/ru/README.md)
* [Установка](guide/ru/install.md)
