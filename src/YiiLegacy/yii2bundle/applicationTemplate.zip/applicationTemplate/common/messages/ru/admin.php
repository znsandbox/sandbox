<?php
return [
	
	'gii' => 'Gii',
	
	'logreader' => 'Логи',
	
	'modules' => 'Модули',
	
	'main' => 'Основное',
	'system' => 'Система',
	'develop' => 'Разработка',
    'tools' => 'Инструменты',
	
	'app' => 'Приложение',
	//'app_cache' => 'Кэш',
	//'app_lang' => 'Язык',
	
	'rbac' => 'RBAC',
	'rbac_permission' => 'Разрешения',
	'rbac_role' => 'Роли',
	'rbac_rule' => 'Правила',
	'rbac_assignment' => 'Назначения',
	

];