<?php
namespace yii2tool\test\models;

use yii2rails\extension\store\ActiveStore;

class Login extends ActiveStore
{
	public static $name = 'rest_login';
	
}
