<?php

return [
	'components' => [
		'user' => [
			'enableSession' => false, // ! important
		],
	],
];
