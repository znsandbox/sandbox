<?php

return include(ROOT_DIR . '/vendor/yii2bundle/yii2-application-template/src/common/messages/ru/action.php');
