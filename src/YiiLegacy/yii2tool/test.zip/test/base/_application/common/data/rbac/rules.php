<?php
return [
    'isWritable' => 'O:43:"yii2bundle\\rbac\\domain\\rules\\IsWritableRule":4:{s:4:"name";s:10:"isWritable";s:10:"attributes";a:4:{s:8:"readonly";b:1;s:11:"is_readonly";b:1;s:8:"writable";b:0;s:11:"is_writable";b:0;}s:9:"createdAt";N;s:9:"updatedAt";N;}',
    'isAuthorMerchant' => 'O:44:"domain\\v4\\account\\rules\\IsAuthorMerchantRule":3:{s:4:"name";s:16:"isAuthorMerchant";s:9:"createdAt";N;s:9:"updatedAt";N;}',
];
