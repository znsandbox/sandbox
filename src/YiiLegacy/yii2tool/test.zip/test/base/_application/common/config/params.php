<?php

return [
	'pageSize' => 25,
];