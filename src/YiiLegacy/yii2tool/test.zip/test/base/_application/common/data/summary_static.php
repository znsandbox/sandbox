<?php

return [
	[
		'name' => 'avatars',
		'type' => 'url',
		'value' => 'images/avatars',
	],
	[
		'name' => 'qr-code',
		'type' => 'url',
		'value' => 'images/qr-code',
	],
	[
		'name' => 'service-pictures',
		'type' => 'url',
		'value' => 'service',
	],
	[
		'name' => 'service-menu-pictures',
		'type' => 'url',
		'value' => 'service_menu',
	],
	[
		'name' => 'bank-pictures',
		'type' => 'url',
		'value' => 'bank',
	],
];
