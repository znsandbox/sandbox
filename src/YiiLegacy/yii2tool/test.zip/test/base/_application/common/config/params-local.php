<?php

return [
	'adminEmail' => 'admin@example.com',
	'supportEmail' => 'support@example.com',
	'robotEmail' => 'robot@example.com',
];
