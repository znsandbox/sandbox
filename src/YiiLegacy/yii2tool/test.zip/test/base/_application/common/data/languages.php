<?php

return include(ROOT_DIR . '/vendor/php7lab/yii2-legacy/src/yii2bundle/lang/domain/data/languages.php');
