<?php

namespace yii2tool\test\base\_application\common\enums\rbac;

use yii2rails\extension\enum\base\BaseEnum;

/**
 * Class RuleEnum
 *
 * Этот класс был сгенерирован автоматически.
 * Не вносите в данный файл изменения, они затрутся при очередной генерации.
 * Изменить набор констант можно через управление RBAC в админке.
 *
 * @package common\enums\rbac
 */
class RuleEnum extends BaseEnum {
	
	const IS_WRITABLE = 'isWritable';
	
}