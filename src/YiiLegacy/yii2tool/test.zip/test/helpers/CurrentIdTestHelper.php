<?php

namespace yii2tool\test\helpers;

use Yii;
use yii2bundle\notify\domain\helpers\test\NotifyTestHelper;
use yii2bundle\rest\domain\entities\RequestEntity;
use yii2bundle\rest\domain\entities\ResponseEntity;
use yii2tool\test\helpers\RestTestHelper;
use yii2rails\app\domain\helpers\EnvService;
use yii2rails\extension\enum\enums\TimeEnum;
use yii2rails\extension\web\enums\HttpMethodEnum;

class CurrentIdTestHelper extends BaseCacheTestHelper
{

}
