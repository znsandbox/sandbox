[![Latest Stable Version](https://poser.pugx.org/yii2bundle/yii2-test/v/stable.png)](https://packagist.org/packages/yii2bundle/yii2-test)
[![Total Downloads](https://poser.pugx.org/yii2bundle/yii2-test/downloads.png)](https://packagist.org/packages/yii2bundle/yii2-test)

## Описание

набор классов для создания автотестов

## Ссылки

* [Руководство](guide/ru/README.md)
