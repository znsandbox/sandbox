RequestEntity
===

Сущность имеет поля:

* `method` - метод запроса
* `uri` - ссылка
* `data` - тело для POST
* `headers` - заголовки
* `options` - опции http-клиента
* `cookies` - куки

