Установка
===

Устанавливаем зависимость:

```
composer require yii2tool/yii2-restclient
```
