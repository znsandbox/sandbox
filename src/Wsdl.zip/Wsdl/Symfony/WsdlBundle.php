<?php

namespace ZnSandbox\Sandbox\Wsdl\Symfony;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ____WsdlBundle extends Bundle
{

}
