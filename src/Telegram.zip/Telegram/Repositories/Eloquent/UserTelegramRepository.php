<?php

namespace ZnLib\Telegram\Domain\Repositories\Eloquent;

use ZnLib\Telegram\Domain\Entities\UserTelegramEntity;
use ZnCore\Db\Db\Base\BaseEloquentCrudRepository;

class UserTelegramRepository extends BaseEloquentCrudRepository
{

    public function tableName() : string
    {
        return 'user_telegram';
    }

    public function getEntityClass() : string
    {
        return UserTelegramEntity::class;
    }

}
