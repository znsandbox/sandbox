<?php

namespace ZnLib\Telegram\Domain\Interfaces;

use App\Core\Entities\RequestEntity;

interface MatcherInterface
{

    public function isMatch(RequestEntity $requestEntity): bool;

}