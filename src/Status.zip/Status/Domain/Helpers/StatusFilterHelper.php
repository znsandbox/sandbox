<?php

namespace ZnSandbox\Sandbox\Status\Domain\Helpers;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use ZnCore\Enum\Constraints\Enum;
use ZnLib\Components\Status\Enums\StatusSimpleEnum;

class StatusFilterHelper
{

    public static function loadStatusValidatorMetadata(ClassMetadata $metadata, string $enumStatus = StatusSimpleEnum::class, string $attributeName = 'statusId')
    {
        $metadata->addPropertyConstraint($attributeName, new Enum([
            'class' => $enumStatus,
        ]));
    }
}
