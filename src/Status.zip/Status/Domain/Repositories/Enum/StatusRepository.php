<?php

namespace ZnSandbox\Sandbox\Status\Domain\Repositories\Enum;

use ZnDomain\Сomponents\EnumRepository\Base\BaseEnumCrudRepository;
use ZnLib\Components\Status\Enums\StatusSimpleEnum;
use ZnSandbox\Sandbox\Status\Domain\Entities\EnumEntity;
use ZnSandbox\Sandbox\Status\Domain\Interfaces\Repositories\StatusRepositoryInterface;

class StatusRepository extends BaseEnumCrudRepository implements StatusRepositoryInterface
{

    private $enumClass = StatusSimpleEnum::class;

    public function enumClass(): string
    {
        return $this->enumClass;
    }

    public function getEntityClass(): string
    {
        return EnumEntity::class;
    }
}
