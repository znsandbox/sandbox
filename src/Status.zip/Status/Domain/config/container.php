<?php

return [
    'singletons' => [
        //'ZnSandbox\Sandbox\Status\Domain\Interfaces\Services\StatusServiceInterface' => 'ZnSandbox\Sandbox\Status\Domain\Services\StatusService',

        'ZnSandbox\Sandbox\Status\Domain\Interfaces\Repositories\StatusRepositoryInterface' => 'ZnSandbox\Sandbox\Status\Domain\Repositories\Enum\StatusRepository',
    ],
];
